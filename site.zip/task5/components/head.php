<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Веб-студия - контактная информация">
    <link rel="canonical" href="http://localhost/task5/index.php">
    <link rel="icon" href="public/favicon.ico">
    <link rel="stylesheet" href="styles/style.css">
    <script src="js/index.js" defer></script>
    <script src="js/jquery-3.7.1.min.js"></script>