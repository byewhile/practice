<header>
    <div>
        <img src="public/favicon.ico" alt="Logo"><h1></h1>
    </div>
    <nav class="nav-links">
        <ul>
            <li><a href="./">Главная страница</a></li>
            <li><a href="portfolio.php">Портфолио</a></li>
            <li><a href="technologies.php">Технологии разработки</a></li>
            <li><a href="cost.php">Калькулятор стоимости</a></li>
            <li><a href="contact.php">Контактная информация</a></li>
            <li><a href="form.php">Форма заявки услуг</a></li>
        </ul>
    </nav>
    
    <span class="menu-icon">&#9776;</span>
    <nav class="hamburger-menu">
        <ul>
            <li><a href="./">Главная страница</a></li>
            <li><a href="portfolio.php">Портфолио</a></li>
            <li><a href="technologies.php">Технологии разработки</a></li>
            <li><a href="cost.php">Калькулятор стоимости</a></li>
            <li><a href="contact.php">Контактная информация</a></li>
            <li><a href="form.php">Форма заявки услуг</a></li>
        </ul>
    </nav>
</header>