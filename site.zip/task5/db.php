<?php
$dbhost = "localhost";
$dbusername = "root";
$dbpassword = "root";
$dbname = "studio";
$conn = new mysqli($dbhost, $dbusername, $dbpassword, $dbname);